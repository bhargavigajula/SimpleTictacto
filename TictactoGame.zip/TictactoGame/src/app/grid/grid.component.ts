import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.css']
})
export class GridComponent implements OnInit {
  squares: string[];
  turn : boolean;
  winner : any;
  constructor() { }

  ngOnInit(): void {
    this.newGame();
  }
  newGame() {
    this.squares = Array(9).fill(null);
    this.winner = null;
    this.turn = true;
  }
  get player(){
     return this.turn ? 'X' : 'O';
  }
  makeMove(idx : any) {
     if(!this.squares[idx]) {
       this.squares.splice(idx,1,this.player);
       this.turn = !this.turn;
     }
     this.winner = this.calculateWinner();
  }
  calculateWinner() {
    var lines = [
      [0,1,2],
      [3,4,5],
      [6,7,8],
      [0,3,6],
      [1,4,7],
      [2,5,8],
      [0,4,8],
      [2,4,6],
    ];
    for(let i = 0;i < lines.length;i++) {
      var [a,b,c] = lines[i];
      if(this.squares[a] && this.squares[a] === this.squares[b] && this.squares[a] === this.squares[c]) {
        return this.squares[a];
      }
    }
    return null;
  }
}
